/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package papelerias;

/**
 *
 * @author formacion15
 */
public class Agenda extends Productos {

    public Agenda() {
        this.stock = 50;
        this.precio = 1.90;
    }

    @Override
    public boolean hayStock(int stockUsuario) {
        return stockUsuario <= this.stock;
    }

}
